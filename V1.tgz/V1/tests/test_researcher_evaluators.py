"""Tests for researcher evaluator rubric conversion.

Verify that the three researcher role-focused evaluators output valid JSON with
score, score_numeric, rubric breakdown, and flat checks after conversion to
the weighted rubric model using evaluate_rubric().
"""

from __future__ import annotations

import json
import subprocess as sp
import sys
from pathlib import Path

import pytest

_REPO_ROOT = Path(__file__).resolve().parent.parent
_TASKS_DIR = _REPO_ROOT / "tasks"

RESEARCHER_EVALUATORS = [
    "researcher-choose-storage-api",
    "researcher-compare-auth-options",
    "researcher-summarize-release-notes",
]


def _run_evaluator_script(task_id: str, answer_text: str) -> dict:
    """Run evaluator by extracting the Python code and executing it."""
    task_dir = _TASKS_DIR / task_id
    run_sh = (task_dir / "evaluate" / "run.sh").read_text()

    lines = run_sh.splitlines()
    py_lines: list[str] = []
    in_heredoc = False
    for line in lines:
        if "python3" in line and "<<'" in line:
            marker = line.strip().split("<<'")[-1].rstrip("'")
            in_heredoc = True
            continue
        if in_heredoc:
            if line.strip() == marker:
                break
            py_lines.append(line)

    import tempfile
    tmpdir = Path(tempfile.mkdtemp(prefix=f"eval-{task_id}-"))
    try:
        (tmpdir / "answer.md").write_text(answer_text)
        code = "\n".join(py_lines)

        result = sp.run(
            [sys.executable, "-c", code],
            capture_output=True, text=True, cwd=str(tmpdir),
        )

        full_out = result.stdout.strip()
        start_idx = full_out.index("{") if "{" in full_out else -1
        if start_idx >= 0:
            return json.loads(full_out[start_idx:])

        raise AssertionError(
            f"evaluator produced no JSON output\nstdout: {result.stdout}\nstderr: {result.stderr}"
        )
    finally:
        import shutil
        shutil.rmtree(str(tmpdir), ignore_errors=True)


# ── Full answers that should pass all checks for each task ───────

def _make_storage_api_answer() -> str:
    return """Researcher Result

## Recommendation

For the storage API, use a blobstore backend with signed download URLs and durable filecache support. Prefer ephemeral caching for temporary artifacts.

The blobstore handles large objects efficiently while signed downloads provide secure access. The filecache layer ensures durability for frequently accessed files.

## Sources

- PRD.md: storage requirements for artifact retention
- kb/storage-api.md: blobstore vs object store comparison

## Tradeoffs

Tradeoffs include latency vs cost: durable blobs are slower but cheaper at scale. Ephemeral caching improves read speed but risks data loss on restart. Confidence is moderate — the KB does not cover multi-region replication.
"""


def _make_auth_options_answer() -> str:
    return """Researcher Result

## Recommendation

For browser-based auth, use session cookie with CSRF protection. For machine-to-machine flows, prefer apikey authentication. Both approaches are well-documented in the knowledge base.

Session cookies provide transparent user experience; csrf tokens prevent cross-site attacks. Apikey auth is simple and reliable for internal service calls.

## Sources

- PRD.md: auth requirements for browser and API consumers
- kb/auth-options.md: session cookie vs JWT comparison

## Tradeoffs

Tradeoffs between simplicity and flexibility: session cookies are simpler but less portable across domains. Apikey avoids round-trips but needs rotation strategy. Confidence is high — the KB covers both patterns in detail.
"""


def _make_release_notes_answer() -> str:
    return """Researcher Result

## Recommendation

The release introduces create_invoice with negative quantities support, send_invoice_email notification flow, canonical json output format, and no database migration requirement for existing data.

Key changes: the create_invoice endpoint now handles negative quantities for credits. The send_invoice_email pipeline uses async delivery. Output follows canonical json ordering for determinism. No database migration is needed — the schema extends backward compatibly.

## Sources

- PRD.md: invoice feature requirements
- kb/release-notes.md: changelog and known issues

## Tradeoffs

Tradeoffs include added complexity in negative quantity handling vs simpler positive-only flow. The canonical json format adds serialization cost but improves cache hits. No database migration reduces deployment risk. Confidence is high for core features; moderate for edge cases around email delivery timing.
"""


ANSWER_MAP = {
    "researcher-choose-storage-api": _make_storage_api_answer,
    "researcher-compare-auth-options": _make_auth_options_answer,
    "researcher-summarize-release-notes": _make_release_notes_answer,
}


# ── 1. Output JSON shape has required fields ─────────

class TestEvaluatorOutputShape:
    """Each converted evaluator outputs score, score_numeric, rubric, and checks."""

    @pytest.mark.parametrize("task_id", RESEARCHER_EVALUATORS)
    def test_has_score(self, task_id):
        result = _run_evaluator_script(task_id, ANSWER_MAP[task_id]())
        assert "score" in result, f"{task_id} evaluator missing 'score' field"
        assert result["score"] in ("pass", "fail")

    @pytest.mark.parametrize("task_id", RESEARCHER_EVALUATORS)
    def test_has_score_numeric(self, task_id):
        result = _run_evaluator_script(task_id, ANSWER_MAP[task_id]())
        assert "score_numeric" in result, f"{task_id} evaluator missing 'score_numeric' field"
        assert isinstance(result["score_numeric"], (int, float))

    @pytest.mark.parametrize("task_id", RESEARCHER_EVALUATORS)
    def test_has_rubric_dict(self, task_id):
        result = _run_evaluator_script(task_id, ANSWER_MAP[task_id]())
        assert "rubric" in result, f"{task_id} evaluator missing 'rubric' field"
        assert isinstance(result["rubric"], dict)

    @pytest.mark.parametrize("task_id", RESEARCHER_EVALUATORS)
    def test_has_flat_checks(self, task_id):
        result = _run_evaluator_script(task_id, ANSWER_MAP[task_id]())
        assert "checks" in result, f"{task_id} evaluator missing 'checks' field"
        assert isinstance(result["checks"], dict)


# ── 2. Full pass yields correct score ─────────

class TestFullPassScore:
    """A complete answer should yield score=pass and meaningful score_numeric."""

    @pytest.mark.parametrize("task_id", RESEARCHER_EVALUATORS)
    def test_full_pass_is_pass(self, task_id):
        result = _run_evaluator_script(task_id, ANSWER_MAP[task_id]())
        assert result["score"] == "pass"

    @pytest.mark.parametrize("task_id", RESEARCHER_EVALUATORS)
    def test_full_pass_score_above_threshold(self, task_id):
        """Full pass should score >= 0.70 (default threshold)."""
        result = _run_evaluator_script(task_id, ANSWER_MAP[task_id]())
        assert result["score_numeric"] >= 0.70, \
            f"{task_id} full answer scored {result['score_numeric']} < 0.70"

    @pytest.mark.parametrize("task_id", RESEARCHER_EVALUATORS)
    def test_score_numeric_not_zero(self, task_id):
        result = _run_evaluator_script(task_id, ANSWER_MAP[task_id]())
        assert result["score_numeric"] > 0


# ── 3. Empty answer yields fail ─────────

class TestEmptyAnswer:
    """An empty or missing answer.md should yield score=fail."""

    @pytest.mark.parametrize("task_id", RESEARCHER_EVALUATORS)
    def test_empty_answer_fails(self, task_id):
        result = _run_evaluator_script(task_id, "")
        assert result["score"] == "fail"


# ── 4. Rubric categories have expected structure ─────────

class TestRubricCategories:
    """Each rubric category has score, max, and checks sub-fields."""

    @pytest.mark.parametrize("task_id", RESEARCHER_EVALUATORS)
    def test_rubric_categories_have_score_max_checks(self, task_id):
        result = _run_evaluator_script(task_id, ANSWER_MAP[task_id]())
        for cat_name, cat_data in result["rubric"].items():
            assert "score" in cat_data, f"{cat_name} missing 'score'"
            assert "max" in cat_data, f"{cat_name} missing 'max'"
            assert "checks" in cat_data, f"{cat_name} missing 'checks'"


# ── 5. Original check names preserved in flat output ─────────

class TestOriginalChecksPreserved:
    """All original check identifiers appear in the flat checks dict."""

    EXPECTED_CHECKS = {
        "researcher-choose-storage-api": [
            "answer_exists", "mentions_researcher", "has_sources",
            "has_recommendation", "has_tradeoffs_or_uncertainty",
            "blobstore", "signed_download", "durable",
            "filecache", "ephemeral", "sources", "tradeoffs",
        ],
        "researcher-compare-auth-options": [
            "answer_exists", "mentions_researcher", "has_sources",
            "has_recommendation", "has_tradeoffs_or_uncertainty",
            "sessioncookie", "csrf", "browser",
            "apikey", "machine_to_machine", "sources", "tradeoffs",
        ],
        "researcher-summarize-release-notes": [
            "answer_exists", "mentions_researcher", "has_sources",
            "has_recommendation", "has_tradeoffs_or_uncertainty",
            "create_invoice", "negative_quantities", "send_invoice_email",
            "canonical_json", "no_database_migration", "sources", "recommendation",
        ],
    }

    @pytest.mark.parametrize("task_id", RESEARCHER_EVALUATORS)
    def test_all_original_checks_present(self, task_id):
        result = _run_evaluator_script(task_id, ANSWER_MAP[task_id]())
        flat = set(result["checks"].keys())
        expected = set(self.EXPECTED_CHECKS[task_id])
        missing = expected - flat
        assert not missing, f"{task_id} evaluator missing checks: {missing}"


# ── 6. Rubric uses evaluate_rubric pattern (code inspection) ───

class TestEvaluatorUsesRubricHelper:
    """Each evaluator script references the rubric evaluation function."""

    @pytest.mark.parametrize("task_id", RESEARCHER_EVALUATORS)
    def test_evaluator_references_evaluate_rubric(self, task_id):
        run_sh = (_TASKS_DIR / task_id / "evaluate" / "run.sh").read_text()
        assert "evaluate_rubric" in run_sh, \
            f"{task_id} evaluator should call evaluate_rubric()"


# ── 7. Threshold default is 0.70 ─────────

class TestThreshold:
    """Evaluators use the default threshold of 0.70 (not overriding)."""

    @pytest.mark.parametrize("task_id", RESEARCHER_EVALUATORS)
    def test_no_custom_threshold_override(self, task_id):
        run_sh = (_TASKS_DIR / task_id / "evaluate" / "run.sh").read_text()
        import re
        matches = re.findall(r'threshold\s*=\s*([0-9.]+)', run_sh)
        for m in matches:
            assert float(m) == pytest.approx(0.70), \
                f"{task_id} has non-standard threshold {m}"
