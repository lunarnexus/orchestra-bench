error: run not found: sshoraclecheck
